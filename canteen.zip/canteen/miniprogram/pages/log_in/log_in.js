// pages/log_in/log_in.js
const db = wx.cloud.database()
const Log = db.collection('log_in')

Page({
    onSubmit: function(event){
        console.log(event)
    }
})