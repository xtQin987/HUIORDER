// pages/main/main.js
// import * as echarts from '../../ec-canvas/echarts';
Page({
    
})